export class Category {
    //member variable
    categoryName:String;
    categoryDescription:String;

    //constructor
    constructor(categoryName:String,catgeoryDescription:String){
        this.categoryName=categoryName;
        this.categoryDescription=catgeoryDescription;
    }
}
